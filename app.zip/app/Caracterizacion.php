<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Caracterizacion extends Model
{
    protected $table = "caracterizacion";
    protected $primaryKey = 'id';
    public $timestamps = false;
}
