<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NucleoFamiliarCaracterizacion extends Model
{
    protected $table = "nucleofamiliar_caracterizacion";
    protected $primaryKey = 'id';
    public $timestamps = false;
}
