@extends('admin.layout')

@section('content')
<h1>Dashboard</h1>
@endsection