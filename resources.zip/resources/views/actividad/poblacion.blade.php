
@extends('admin.layout')

@section('content')
{{--<div class="callout callout-info">
  <h5> Meta:</h5>
  {{ $meta->nombre }}
</div>--}}
<!-- listado de Poblacion -->
@if(count($poblacion)>0)
<div class="row">
    <div class="col-md-12">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title">Lista de Población</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
            </div>
            <div class="card-body">      
                <table id="tblActividad" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre(s) y Apellido(s)</th>                                               
                        <th scope="col">Documento</th>                                               
                        <th scope="col">Sexo</th>
                        <th scope="col">Edad</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($poblacion as $item)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $item->nombres_completos }}</td>
                            <td>{{ $item->documento }}</td>
                            <td>{{ $item->sexo }}</td>
                            <td>{{ $item->edad }}</td>                           
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <!-- fin card body -->
            </div>
        </div>
    </div>
</div>
@else
  <h3>Esta actividad no tiene población</h3>
@endif
@endsection