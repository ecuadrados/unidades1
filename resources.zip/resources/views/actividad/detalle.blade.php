
@extends('admin.layout')

@section('content')
{{--<div class="callout callout-info">
  <h5> Meta:</h5>
  {{ $meta->nombre }}
</div>--}}
<div class="card card-primary">
  <div class="card-header">
    <h3 class="card-title">Insertar Población</h3>
    <div class="card-tools">
      <!-- Buttons, labels, and many other things can be placed here! -->
      <!-- Here is a label for example -->
    </div>
    <!-- /.card-tools -->
  </div>
  <!-- /.card-header -->  
  <div class="card-body">
        
            <form action="{{ route('actividad.poblacion') }}" class="d-inline" method="POST">
                @csrf
                <div class="card-body">
                  <div class="row callout callout-info">
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="poblacion_objeto">Población Objeto</label>
                      <input type="text" name="poblacion_objeto" class="form-control" id="poblacion_objeto" placeholder="Ingrese población" required>
                      <input type="hidden" id="actividad_id" name="actividad_id" value="{{$actividad->id}}">
                      <textarea name="datos_poblacion" class="form-control" id="datos_poblacion" rows="3" cols="40" style="display: none;"></textarea>
                    </div>                 
                    <div class="form-group col-md-3 col-sm-12">
                        <label for="organizacion_actividad">Organización o Institución</label>
                        <input type="text" name="organizacion_actividad" class="form-control" id="organizacion_actividad" placeholder="Ingrese Organización o Institución" required>
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                        <label for="lugar_actividad">Lugar de Actividad</label>
                        <input type="text" name="lugar_actividad" class="form-control" id="lugar_actividad" placeholder="Ingrese Lugar de la Actividad" required>
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                        <label for="fecha_actividad">Fecha de Actividad</label>
                        <input type="date" name="fecha_actividad" class="form-control" id="fecha_actividad" placeholder="Ingrese Fecha de la Actividad" required>
                    </div>                 
                  </div>
                  <!-- row -->
                  <div class="row" style="margin-top: 2rem;"><h3>Insertar Población</h3></div>
                  <div class="row">
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="nombres_completos">Nombre(s) y Apellido(s)</label>
                      <input type="text" name="nombres_completos" class="form-control" id="nombres_completos" placeholder="Ingrese Nombre(s) y Apellido(s)">
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                    <label>Sexo</label><br>
                      <label><input type="radio" name="Sexo" value="Femenino"> Femenino</label>
                      <label><input type="radio" name="Sexo" value="Masculino"> Masculino</label>
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Documento">Documento</label>
                      <input type="text" name="Documento" class="form-control" id="Documento" placeholder="Ingrese Documento">
                    </div>                    
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Edad">Edad</label>
                      <input type="text" name="Edad" class="form-control" id="Edad" placeholder="Edad">
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                      <label>Etnia</label>                 
                        <select class="form-control select2" name="Etnia" id="Etnia" style="width: 100%;">
                          <option value="">Seleccione</option>
                          <option value="Afro">Afro</option>
                          <option value="Mestizo">Mestizo</option>
                          <option value="Indigena">Indigena</option>
                          <option value="Otro">Otro</option>
                        </select>                          
                    </div> 
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Inclusion">Inclusión</label>
                      <input type="text" name="Inclusion" class="form-control" id="Inclusion"  placeholder="Inclusion">
                    </div>                                                                               
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Organizado_Proyecto">Organizado_Proyecto</label>
                      <input type="text" name="Organizado_Proyecto" class="form-control" id="Organizado_Proyecto"  placeholder="Organizado_Proyecto">
                    </div>                    
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Telefono">Telefono</label>
                      <input type="text" name="Telefono" class="form-control" id="Telefono"  placeholder="Telefono">
                    </div>                    
                    <div class="form-group col-md-3 col-sm-12">
                      <label for="Celular">Celular</label>
                      <input type="text" name="Celular" class="form-control" id="Celular"  placeholder="Celular">
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                      <label>Funcionario</label>                 
                      <select class="form-control select2" name="Funcionario" id="Funcionario" style="width: 100%;">
                        <option value="">Seleccione</option>
                        <option value="NOMBRE 1">NOMBRE 1</option>
                        <option value="NOMBRE 2">NOMBRE 2</option>
                        <option value="NOMBRE 3">NOMBRE 3</option>
                        <option value="Otro">Otro</option>
                      </select>
                    </div>
                    <div class="form-group col-md-3 col-sm-12">
                    <button type="button" name="btnAgregar" id="btnAgregar" class="btn btn-primary btn-sm" onclick="agregarPoblacion()">Agregar</button>

                    </div>
	  
                  </div>
                  <!-- row -->
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>                      
  </div>
  <!-- /.card-body --> 
</div>
<!-- listado de Actividades -->
{{-- @if(count($actividad)>0)
<div class="row">
    <div class="col-md-12">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title">Lista de Actividades para esta meta</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
            </div>
            <div class="card-body">      
                <table id="tblActividad" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Actividad</th>                                               
                        <th scope="col">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($actividad as $item)
                        <tr>
                            <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $item->nombre }}</td>
                            <td>                                                                     
                              <a href="{{route('actividad.show', $item)}}" class="btn btn-success btn-sm">Población</a>
                              <a href="{{route('contratista.edit', $item)}}" class="btn btn-warning btn-sm">Editar</a>
                                <form action="{{ route('actividad.destroy', $item) }}" class="d-inline" method="POST">
                                    @method('DELETE')
                                    @csrf
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Esta Seguro?')">Borrar</button>
                                </form> 
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <!-- fin card body -->
            </div>
        </div>
    </div>
</div>
@else
  <h3>Esta meta no tiene actividades</h3>
@endif --}}
<script>
  var poblacion = [];
  function agregarPoblacion(){
    
    let nombre_completo = $("#nombres_completos").val();
    let sexo = $("input[name='Sexo']:checked").val();
    let documento = $("#Documento").val();
    let Edad = $("#Edad").val();
    let Etnia =$("#Etnia").val();
    let Inclusion = $("#Inclusion").val();
    let Organizado_Proyecto = $("#Organizado_Proyecto").val();
    let Telefono =$("#Telefono").val();
    let Celular = $("#Celular").val();
    let Funcionario =$("#Funcionario").val();

    objPoblacion = {'nombre_completo':nombre_completo,'sexo': sexo,
    'documento':documento, 'edad':Edad, 'etnia':Etnia, 'inclusion':Inclusion,
    'organizado_proyecto':Organizado_Proyecto, 'telefono':Telefono, 
    'celular': Celular, 'funcionario': Funcionario}
    poblacion.push(objPoblacion);
    console.log(poblacion);

    $("#datos_poblacion").val( JSON.stringify(poblacion));
    $("#nombres_completos").val("");
    $("input[name='Sexo']:checked").val("");
    $("#Documento").val("");
    $("#Edad").val("");
    $("#Etnia").val("");
    $("#Inclusion").val("");
    $("#Lugar_de_Actividad").val("");
    $("#Organizado_Proyecto").val("");
    $("#Telefono").val("");
    $("#Celular").val("");
    $("#Funcionario").val("");
  }
</script>
@endsection