@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="alert alert-success" role="alert">
      Beneficiario insertado correctamente
    </div>
</div>

@endsection
