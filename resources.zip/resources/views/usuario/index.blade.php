@extends('admin.layout')


@section('content')
<div class="container-fluid">
    <div class="alert alert-success" role="alert">
      Usuario insertado correctamente
    </div>
</div>

@endsection
