@extends('admin.layout')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
    </div>
</div>
@endsection
