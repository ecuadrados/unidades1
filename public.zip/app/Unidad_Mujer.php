<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unidad_Mujer extends Model
{
    //
}
